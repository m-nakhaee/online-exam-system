package onlineSchool.controller.restControlers;

import onlineSchool.model.entity.Quiz;
import onlineSchool.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class QuizRestController {
    @Autowired
    QuizService quizService;

    @PostMapping(value = "/updateQuiz")
    public String updateQuiz(@RequestBody Quiz quiz) { //TODO ret val ro void kon
        quizService.update(quiz);
        return "quiz updated successfully!";
    }

    @PostMapping(value = "/saveQuiz")
    public Integer saveQuiz(@RequestBody Quiz quiz) { //TODO ret val ro void kon
        Integer id = quizService.save(quiz);
        return id;
    }

}
