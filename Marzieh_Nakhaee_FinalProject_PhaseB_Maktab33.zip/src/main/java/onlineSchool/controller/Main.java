package onlineSchool.controller;

import onlineSchool.configuration.DataBaseContext;
import onlineSchool.exceptions.NotAvailableUserException;
import onlineSchool.exceptions.PasswordException;
import onlineSchool.model.dao.CourseDao;
import onlineSchool.model.dao.UserDao;
import onlineSchool.model.entity.Course;
import onlineSchool.model.entity.User;
import onlineSchool.service.CourseService;
import onlineSchool.service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;
import java.util.Set;

public class Main {
    static ApplicationContext applicationContext = new AnnotationConfigApplicationContext(DataBaseContext.class);


    public static void main(String[] args) throws PasswordException, NotAvailableUserException {
        UserDao userDao = (UserDao) applicationContext.getBean("userDao");
        UserService userService = (UserService) applicationContext.getBean("userService");
        CourseDao courseDao = (CourseDao) applicationContext.getBean("courseDao");
//        User user = new User();
//        user.setEmail("8531nakhaei@gmail.com");
//        user.setPassword("aaaa1111");
//        User login = userService.login(user);
//        System.out.println(login.getCourseList());
//        List<User> userList = userService.getCourseStudents(0, maktab22);
//        System.out.println(userList);
    }
}
