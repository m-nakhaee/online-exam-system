package onlineSchool.controller;

import onlineSchool.model.entity.Course;
import onlineSchool.model.entity.Quiz;
import onlineSchool.model.entity.User;
import onlineSchool.service.CourseService;
import onlineSchool.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Controller
public class CourseController {

    @Autowired
    CourseService courseService;
    @Autowired
    UserService userService;

    @GetMapping(value = "/courseStudents")
    public String getCourseStudents(@RequestParam("courseTitle") String courseTitle, Model model) {
        Course course = new Course();
        course.setTitle(courseTitle);
        List<Course> courseList = courseService.getFilteredCourse(0, course);
        List<User> courseStudents = userService.getCourseStudents(0, courseList.get(0));
        model.addAttribute("courseStudents", courseStudents);
        model.addAttribute("courseTitle", courseTitle);
        return "decelerations/courseStudentsPage";
    }

    @GetMapping(value = "/courseQuizzes")
    public String getCourseQuizzes(@RequestParam("courseTitle") String courseTitle
            , @RequestParam("teacherId") Integer teacherId, Model model) {
        Course course = new Course();
        course.setTitle(courseTitle);
        List<Course> courseList = courseService.getFilteredCourse(0, course);
        Set<Quiz> quizSet = courseList.get(0).getQuizSet();
        List<Quiz> quizList = new ArrayList<>();
        quizList.addAll(quizSet);
        model.addAttribute("courseQuizzes", quizList);
        model.addAttribute("teacherId", teacherId);
        model.addAttribute("courseTitle", courseTitle);
        return "decelerations/courseQuizzesPage";
    }
}
