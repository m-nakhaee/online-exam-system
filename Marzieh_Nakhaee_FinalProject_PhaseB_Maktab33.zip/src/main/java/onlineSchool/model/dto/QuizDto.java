package onlineSchool.model.dto;

public class QuizDto {
}
