package onlineSchool.model.dao;

import onlineSchool.model.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.Repository;

@org.springframework.stereotype.Repository
public interface AdminDao extends JpaRepository<Admin, Integer> {

}