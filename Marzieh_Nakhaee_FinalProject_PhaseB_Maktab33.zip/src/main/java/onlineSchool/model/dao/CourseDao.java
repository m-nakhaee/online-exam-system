package onlineSchool.model.dao;

import onlineSchool.model.entity.Course;
import onlineSchool.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CourseDao extends JpaRepository<Course, Integer>, JpaSpecificationExecutor<Course> {
}
