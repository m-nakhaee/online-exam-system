package onlineSchool.service;

import onlineSchool.model.dao.QuizDao;
import onlineSchool.model.entity.Quiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Objects;
import java.util.Optional;

@Service
public class QuizService {
    @Autowired
    QuizDao quizDao;

    @Transactional
    public Integer save(Quiz quiz){
        quizDao.save(quiz);
        return quiz.getId();
    }

    @Transactional
    public void update(Quiz quizUpdate) {
        Optional<Quiz> byId = quizDao.findById(quizUpdate.getId());
        if (byId.isPresent()) {
            Quiz quiz = byId.get();
            if (Objects.nonNull(quizUpdate.getTitle()))
                quiz.setTitle(quizUpdate.getTitle());
            if (Objects.nonNull(quizUpdate.getDescription()))
                quiz.setDescription(quizUpdate.getDescription());
            if (Objects.nonNull(quizUpdate.getTime()))
                quiz.setTime(quizUpdate.getTime());
            if (Objects.nonNull(quizUpdate.getStartDate()))
                quiz.setStartDate(quizUpdate.getStartDate());
            if (Objects.nonNull(quizUpdate.getEndDate()))
                quiz.setEndDate(quizUpdate.getEndDate());
            if (Objects.nonNull(quizUpdate.getQuestionSet()))
                quiz.setQuestionSet(quizUpdate.getQuestionSet());
            if (Objects.nonNull(quizUpdate.getState()))
                quiz.setState(quizUpdate.getState());
        }
    }
}
