package onlineSchool.service;

import onlineSchool.model.dto.MasterDto;
import onlineSchool.model.dto.StudentDto;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    public boolean confirmRegister(){
        //TODO
        return false;
    }

}
