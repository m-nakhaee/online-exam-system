package onlineSchool.enumeration;

public enum RoleEnum {
    teacher, student;
}
