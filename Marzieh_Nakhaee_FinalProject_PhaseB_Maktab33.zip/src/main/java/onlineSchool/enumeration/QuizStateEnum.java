package onlineSchool.enumeration;

public enum  QuizStateEnum {
    available, stopped
}
