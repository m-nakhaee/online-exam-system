package onlineSchool.exceptions;

public class NotAvailableUserException extends Exception {
    public NotAvailableUserException(String message) {
        super(message);
    }
}
