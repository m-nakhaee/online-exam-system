package onlineSchool.service;

import onlineSchool.model.dto.MasterDto;
import onlineSchool.model.dto.StudentDto;
import onlineSchool.model.entity.Teacher;
import onlineSchool.model.entity.Student;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    public boolean confirmRegister(){
        //TODO
        return false;
    }
    public StudentDto searchStudent(Student student){
        //TODO
        return null;
    }
    public MasterDto searchMaster(Teacher teacher){
        //TODO
        return null;
    }
}
