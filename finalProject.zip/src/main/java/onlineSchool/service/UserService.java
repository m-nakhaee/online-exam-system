package onlineSchool.service;

import onlineSchool.exceptions.DuplicateUserException;
import onlineSchool.exceptions.InvalidInputException;
import onlineSchool.exceptions.NotAvailableUserException;
import onlineSchool.exceptions.PasswordException;
import onlineSchool.model.dao.UserDao;
import onlineSchool.model.entity.Course;
import onlineSchool.model.entity.Role;
import onlineSchool.model.entity.Status;
import onlineSchool.model.entity.User;
import onlineSchool.model.specification.UserSpecification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class UserService {

//    @Autowired
//    PasswordEncoder passwordEncoder;

    private UserDao userDao;

    @Autowired
    public UserService(UserDao userDao) {
        this.userDao = userDao;
    }

    public List<Course> getCourses(String email){
        return userDao.getCourses(email);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void register(User user) throws DuplicateUserException {
        Optional<User> found = userDao.findByEmail(user.getEmail());
        if (!found.isPresent()) {
//            user.setPassword(passwordEncoder.encode(user.getPassword()));
            userDao.save(user);
        } else throw new DuplicateUserException();
    }

    public void remove(User user) {
        userDao.delete(user);
    }

//    @Transactional(propagation = Propagation.REQUIRED)
    public User login(User userLogin) throws NotAvailableUserException, PasswordException {
        User user;
        Optional<User> foundUser = userDao.findByEmail(userLogin.getEmail());
        if (foundUser.isPresent()) user = foundUser.get();
        else throw new NotAvailableUserException();
        String userLoginPassword = userLogin.getPassword();
        String userPassword = user.getPassword();
        if (!Objects.equals(userLoginPassword, userPassword))
            throw new PasswordException("incorrect password");
        return user;
    }

    @Transactional
    public void confirmEmailAddress(User user) {
        Status status = new Status();
        status.setId(2);
        user.setStatus(status);
        userDao.update(user.getEmail(), user.getStatus());
    }

    @Transactional
    public List<User> getFilteredUsers(int pageNumber, User user) {
        Pageable pageable = PageRequest.of(pageNumber, 10);
        Page<User> users = userDao.findAll(UserSpecification.findMaxMatch(user), pageable);
        return users.getContent();
    }

    public List<User> getAllUsers(int pageNumber) {
        Pageable pageable = PageRequest.of(pageNumber, 10);
        Page<User> users = userDao.findAll(pageable);
        return users.getContent();
    }

    public void update(User user) {
        String email = user.getEmail();
        String firstName = user.getFirstName();
        String lastName = user.getLastName();
        String password = user.getPassword();
        Role role = user.getRole();
        Status status = user.getStatus();
        if (!StringUtils.isEmpty(firstName))
            userDao.updateFirstName(email, firstName);
        if (!StringUtils.isEmpty(lastName))
            userDao.updateLastName(email, lastName);
        if (!StringUtils.isEmpty(password))
            userDao.updatePassword(email, password);
        if (!StringUtils.isEmpty(status.getName())) {
            if (Objects.equals(status.getName(), "email confirm waiting..."))
                status.setId(1);
            if (Objects.equals(status.getName(), "admin accept waiting..."))
                status.setId(2);
            userDao.update(email, status);
        }
        if (!StringUtils.isEmpty(user.getRole().getName())){
            if (Objects.equals(role.getName(), "master"))
                role.setId(1);
            if (Objects.equals(role.getName(), "student"))
                role.setId(2);
//            userDao.update(email, role);
        }
    }
}
