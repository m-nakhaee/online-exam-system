package onlineSchool.service;

import onlineSchool.model.dao.CourseDao;
import onlineSchool.model.entity.Course;
import onlineSchool.model.entity.Teacher;
import onlineSchool.model.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class CourseService {
@Autowired
    CourseDao courseDao;
//    public List<Course> getCourses(Teacher teacher){
//        return courseDao.findByUserList(Arrays.asList(teacher));
//    }
}
