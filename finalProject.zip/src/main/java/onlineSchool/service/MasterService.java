package onlineSchool.service;

import onlineSchool.model.entity.Teacher;
import org.springframework.stereotype.Service;

@Service
public class MasterService {
    public void register(Teacher teacher) {
        //TODO
    }
}
