package onlineSchool.model.dao;

public class QuestionDao {
}
