package onlineSchool.model.dto;

public class MasterDto {
}
