package onlineSchool.model.dto;

public class AdminDto {
}
