package onlineSchool.exceptions;

public class PasswordException extends Exception{
    public PasswordException(String s) {
        super(s);
    }
}
