package onlineSchool.exceptions;

public class NotAvailableUserException extends Exception {
}
