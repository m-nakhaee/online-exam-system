package onlineSchool.exceptions;

public class DuplicateUserException extends Exception {
}
