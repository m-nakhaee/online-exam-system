package onlineSchool.exceptions;

public class CurrentLoginException extends Exception{
    public CurrentLoginException(String s) {
        super(s);
    }
}
