package onlineSchool.controller;

import onlineSchool.exceptions.NotAvailableUserException;
import onlineSchool.exceptions.PasswordException;
import onlineSchool.model.entity.User;
import onlineSchool.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TeacherController {
    @Autowired
    UserService userService;

    @GetMapping(value = "/teacherPanel")
    public String getTeacherPanel(Model model) {
        User user = new User();
        user.setEmail("8531nakhaei@gmail.com");
        user.setPassword("aaaa1111");
        try {
            user = userService.login(user);
        } catch (NotAvailableUserException | PasswordException e) {
            e.printStackTrace();
        }
        model.addAttribute("user", user);
        return "panels/teacherPanelPage";
    }
}
