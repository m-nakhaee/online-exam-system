package onlineSchool.controller.restControlers;

import onlineSchool.model.entity.Course;
import onlineSchool.model.entity.Teacher;
import onlineSchool.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CourseRestController {
    @Autowired
    CourseService courseService;

//    @GetMapping(value = "/getCourses")
//    public List<Course> getCourses(@ModelAttribute Teacher teacher) {
//        return courseService.getCourses(teacher);
//    }
}
