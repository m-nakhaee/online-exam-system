package onlineSchool.controller;

import onlineSchool.configuration.DataBaseContext;
import onlineSchool.exceptions.NotAvailableUserException;
import onlineSchool.exceptions.PasswordException;
import onlineSchool.model.dao.TeacherDao;
import onlineSchool.model.dao.UserDao;
import onlineSchool.model.entity.Teacher;
import onlineSchool.model.entity.User;
import onlineSchool.service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    static ApplicationContext applicationContext = new AnnotationConfigApplicationContext(DataBaseContext.class);


    public static void main(String[] args) throws PasswordException, NotAvailableUserException {
        UserDao userDao = (UserDao) applicationContext.getBean("userDao");
        TeacherDao teacherDao = (TeacherDao) applicationContext.getBean("teacherDao");
        UserService userService = (UserService) applicationContext.getBean("userService");
        User user = new User();
        user.setEmail("homa@gmail.com");
        user.setPassword("aaaa1111");
        User login = userService.login(user);
        System.out.println(login.getFirstName());
    }
}
