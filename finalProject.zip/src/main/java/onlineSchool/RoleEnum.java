package onlineSchool;

public enum RoleEnum {
    teacher, student;
}
