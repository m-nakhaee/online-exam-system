package onlineSchool.aspect;

import org.aspectj.lang.annotation.Around;
import org.springframework.stereotype.Component;

@Component
@org.aspectj.lang.annotation.Aspect
public class Aspect {

    
    public void logForMethod(){

    }
}
